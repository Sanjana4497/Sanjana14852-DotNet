﻿select * from dept;
select * from emp order by deptno;
delete froom emp where empno < 7000

﻿use EFCodeFirstDB
sp_help 'Product'

sp_help 'Category'

select * from [dbo].[__EFMigrationsHistory]

select * from Category;
select * from Product;
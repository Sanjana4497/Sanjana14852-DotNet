﻿using System;
using System.Collections.Generic;

#nullable disable

namespace EFCOREDBFIRSTAPP.Models
{
    public partial class Userdatum
    {
        public string Name { get; set; }
        public string Password { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using EFCOREDBFIRSTAPP.Models;

namespace EFCOREDBFIRSTAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            TrainingContext db = new TrainingContext();
            IEnumerable<Emp> empData = db.Emps.ToList();

            foreach (Emp item in empData)
            {
                Console.WriteLine(item.Empno + " " + item.Ename + " " + item.Job + " " + item.Sal + " " + item.Deptno);
            }

            //list all emps as per jobs

            //print total sal
            var empSal = db.Emps.Sum(e => e.Sal);
            Console.WriteLine("total sal of all emp = " + empSal);

            //print total sal for each dept

            var query10 = db.Emps.GroupBy(e => e.Deptno).Select(e => new
            {
                dept = e.Key,
                salsum = e.Sum(e =>
                e.Sal)
            });




            //list dept and emps for that dept

            //10
            //...
            //...
            //20
            //...
            //...

            //join

            //empname, job,sal,empname
            //inner join
            //declarative
            var joinData = from e in db.Emps
                           join d in db.Emps
            on e.Deptno equals d.Deptno
                           select new { EmpName = e.Ename, e.Job, e.Sal, DeptName = d.Deptno };
            //method syntax
            var joinData1 = db.Emps.Join(db.Depts, e => e.Deptno, d => d.Deptno, (e, d) => new { e.Ename, d.Dname });

            foreach (var item in joinData)
            {
                Console.WriteLine(item.EmpName + " " + item.Job + " " + item.Sal + " " + item.DeptName);
            }

            //left outer join
            //King

            var joinData2 = from e in db.Emps join d in db.Depts on e.Deptno equals d.Deptno into empdept from d in empdept.DefaultIfEmpty() select new { e.Ename, d.Dname };
                            foreach(var item in joinData2)
            {
                Console.WriteLine(item.Ename + " " + item.Dname);
            }

        }
    }
}


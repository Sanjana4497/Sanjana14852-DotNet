﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

 

namespace LINQDemo
{
    static class ExtensionmethodDemo
    {
        //extension method
        //first parameter of a stati method will be declare with keyword this
        //this means extending this type
        public static int WordCount(this string str)
        {
            return str.Split(new char[] { ' ' }).Length;



            //string[] strArray = str.Split(new char[] { ' ' }).Length;



        }
    }
}
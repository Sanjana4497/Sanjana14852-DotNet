﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Array- Link to Object
            //create integer array initialize with few numbers
            //int[] numArray = { 4, 5, 20, 6, 9, 2, 3 };


            //from the array print even numbers

            //declarartive
            //IEnumerable<int> evenData = from num in numArray where num % 2 == 0 select num;
            //foreach (var item in evenData)
            //{
            //    Console.WriteLine(item);
            //}


            // same using method syntax - lambda (input param) => expression
            //IEnumerable<int> evenData1 = numArray.Where(num => num % 2 == 0);


            //foreach (int item in evenData1)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("-----------------------------------------------------------");

            //print square of each number from array
            //declarartive
            //IEnumerable<int> numArraySquare = from num in numArray orderby num descending select num * num;

            //method syntax
            //IEnumerable<int> numArraySquare1 = numArray.OrderBy(n=>n).Select(n => n * n);

            //foreach (int item in numArraySquare1)
            //{
            //    Console.WriteLine(item);
            //}


            //string message = "Hello welcome to LINQ";
            //Console.WriteLine(message.WordCount());
            //how many words in message



            #endregion

            #region generic collection

            List<Employee> empList = new List<Employee>()
            {
                //object initializer
                new Employee { EmpName="bhavana", Address="mumbai", Department="accounts", Salary=15000},
                new Employee { EmpName="vishal", Address="pune", Department="sales", Salary=18000},
                new Employee { EmpName="kavita", Address="mumbai", Department="sales", Salary=25000},
                new Employee { EmpName="amit", Address="mumbai", Department="accounts", Salary=20000},
                new Employee { EmpName="hemant", Address="pune", Department="sales", Salary=27000},
                new Employee { EmpName="aarti", Address="pune", Department="accounts", Salary=30000},
                new Employee { EmpName="varsha", Address="mumbai", Department="accounts", Salary=15000}
            };

            //where 
            //list all emp staying in mumbai
            //declarative
            IEnumerable<Employee> query1 = from e in empList where e.Address == "mumbai" select e;

            //syntax method
            query1 = empList.Where(e => e.Address == "mumbai");

            //immediate execution query
            //ToList() - collection
            IEnumerable<Employee> query2 = (from e in empList where e.Address == "mumbai" select e).ToList();
            query2 = empList.Where(e => e.Address == "mumbai").ToList();

            //execution: defered execution and immediate execution
            //foreach (Employee item in query2)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.WriteLine("------------------------------------------------------------------------------------------");

            //-------------------
            empList.Add(new Employee { EmpName = "nancy", Address = "mumbai", Department = "sales", Salary = 25000 });

            //foreach (Employee item in query2)
            //{
            //    Console.WriteLine(item);
            //}

            //  Console.WriteLine("--------------------------------------------------------------------------");
            //-----------------------------immediate execution method for single record
            //First() / FirstOrDefault() / Single() / SingleOrDefault
            //search record of vishal
            //Employee employee = (from e in empList where e.EmpName == "vishal" select e).FirstOrDefault();
            //method syntax
            // employee = empList.Where(e => e.EmpName == "vishal").Single();
            //employee = empList.Single(e => e.EmpName == "vishal");

            //Console.WriteLine("search : " + employee);

            //--------------------------------------------------------anonymous type
            //Console.WriteLine("-------------------------------------------------------------");
            //list empname, dept, salary

            //var query4 = from e in empList where e.Salary > 20000 select new { e.EmpName, job = e.Department, e.Salary };

            //query4 = empList.Select(e => new { e.EmpName, job = e.Department, e.Salary });

            //foreach (var item in query4)
            // {
            //     Console.WriteLine(item.EmpName + " " + item.job + " " + item.Salary + "-" + item.GetType().Name);
            // }


            //list all emp sort on dept

            // IEnumerable<Employee> query5 = from e in empList orderby e.Department select e;
            // query5 = empList.OrderBy(e => e.Department);

            // foreach (var item in query5)
            // {
            //      Console.WriteLine(item.EmpName+" "+item.Department);
            // }

            //Console.WriteLine("----------------------------------------");

            //list all emp sort on dept,within dept on salary h to l
            //IEnumerable<Employee> query7 = from e in empList orderby e.Department, e.Salary descending select e;

            //query7 = empList.OrderBy(e => e.Department).ThenByDescending(e => e.Salary);

            //foreach (var item in query7)
            //{
            //    Console.WriteLine(item);
            //}



            //distinct deptname
            // IEnumerable<string> deptnames = (from e in empList select e.Department).Distinct();

            //foreach (string item in deptnames)
            //{
            //    Console.WriteLine(item);
            //}

            //group by
            //account
            //..........
            //..........
            //sales
            //..........
            //..........


            //declarartive
            //var query7 = from e in empList group e by e.Department;
            //method syntax
            //query7 = empList.GroupBy(e => e.Department);
            //foreach (var item in query7)
            //{
            //    Console.WriteLine(item.Key);
            //    foreach (var subitem in item)
            //    {
            //        Console.WriteLine("\t" + subitem.EmpName + " " + subitem.Address + " " + subitem.Salary);
            //    }
            //}

            //top 2 highest paid emps
            //  IEnumerable<Employee> query8 = (from e in empList orderby e.Salary descending select e).Take(2);

            //foreach (Employee item in query8)
            //{
            //    Console.WriteLine(item);
            //}

            //use of let
            //var query9 = from e in empList
            //             let bonus = e.Salary * .1m
            //             where bonus > 2500
            //             orderby bonus
            //             select new { e.EmpName, e.Salary, bonus };

            //foreach (var item in query9)
            //{
            //    Console.WriteLine(item.EmpName + " " + item.Salary + " " + item.bonus);
            //}


            //aggregate function
            //total sal of all emps

            decimal totalSalary = (from e in empList select e).Sum(e => e.Salary);
            Console.WriteLine("total sal of all emp = " + totalSalary);

            //print min sal
            decimal minSalary = (from e in empList select e).Min(e => e.Salary);
            Console.WriteLine("Minimum sal of all emp = " + minSalary);

            //print max sal
            decimal maxSalary = (from e in empList select e).Max(e => e.Salary);
            Console.WriteLine("Maximum sal of all emp = " + maxSalary);

            //print avg sal

            decimal avgSalary = (from e in empList select e).Average(e => e.Salary);
            Console.WriteLine("Average sal of all emp = " + avgSalary);

            //deptwise total salary
            //declarative 
            var query10 = from e in empList
                          group e by e.Department into empgrp
                          select new { dept = empgrp.Key, salSum = empgrp.Sum(e => e.Salary) };

            foreach (var item in query10)
            {
                Console.WriteLine(item.dept + " " + item.salSum);
            }

            //method syntax
            var query11 = empList.GroupBy(e => e.Department).Select(e => new { dept = e.Key, salSum = e.Sum(e => e.Salary) });
            // (e => e.Department).ThenByDescending(e => e.Salary);

            foreach (var item in query11)
            {
                Console.WriteLine(item.dept + " " + item.salSum);
            }

            //accounts mumbai
            //declarative
            //var query12 = from emp in empList
            //              group emp by new { emp.Department, emp.Address };
            //foreach (var item in query12)
            //{
            //    Console.WriteLine("\n");
            //    Console.WriteLine(item.Key.Department + item.Key.Address + " total Employee = " + item.Count().ToString());
            //    foreach (var e in item)
            //    {
            //        Console.WriteLine("\t" + e.ToString());
            //    }
            //}

            //syntax
            var query13 = empList.GroupBy(emp => new { emp.Department, emp.Address }).OrderBy(grp=>grp.Key.Department);
            foreach (var item in query13)
            {
                Console.WriteLine("\n");
                Console.WriteLine(item.Key.Department + item.Key.Address + " total Employee = " + item.Count().ToString());
                foreach (var e in item)
                {
                    Console.WriteLine("\t" + e.ToString());
                }
            }

            //accounts pune

            //sales mumbai

            //accounts pune


            #endregion

        }

    }
    }

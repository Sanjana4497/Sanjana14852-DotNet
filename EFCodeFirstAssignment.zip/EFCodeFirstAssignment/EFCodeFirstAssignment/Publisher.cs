﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.ComponentModel.DataAnnotations;
//using System.ComponentModel.DataAnnotations.Schema;

//namespace EFCodeFirstAssignment
//{
//    public class Publisher
//    {
//        [Key]
//        [DatabaseGenerated(DatabaseGeneratedOption.None)]

//        public int PublisherId { get; set; }

//        [Column(TypeName = "varchar(20)")]

//        public int PublisherName { get; set; }


//        [Column(TypeName = "varchar(20)")]

//        public string Country { get; set; }
//        public ICollection<Book> Book { get; set; }

//    }
//}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;




namespace EFCodeFirstAssignment
{
    [Table("Publisher")]
    public class Publisher
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PublisherId { get; set; }

        [Column(TypeName = "varchar(20)")]
        public string PublisherName { get; set; }
        [Column(TypeName = "varchar(20)")]
        public string Country { get; set; }
        public ICollection<Book> BookCollection { get; set; }
    }
}


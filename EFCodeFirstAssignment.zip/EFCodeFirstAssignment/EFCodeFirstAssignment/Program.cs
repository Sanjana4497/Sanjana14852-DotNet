﻿using EFCodeFirstAssignment;
using System;
using System.Linq;



namespace EFCodeFirstAssignment
{
   public class Program
    {
        static void Main(string[] args)
        {
            SeedDatabase();
        }
        private static void SeedDatabase()
        { 
            BookDBContext db = new BookDBContext();

            Publisher publisher1 = new Publisher()
            {
                PublisherId = 101,
                PublisherName = "Manan",
                Country = "India"
            };

            db.Publishers.Add(publisher1);
            db.SaveChanges();


            Book book1 = new Book()
            {
                BookId = 102,
                BookName = "The House of Mirth",
                Publisher  = publisher1
            };

            db.Books.Add(book1);
            db.SaveChanges();


            Member member1 = new Member()
            {
                MemberId = 2,
                MemberName = "John Smith"
            };

            db.Members.Add(member1);
            db.SaveChanges();


            Review review1 = new Review()
            {
                ReviewId = 1002,
                Book = book1,
                Member = member1,
                ReviewText = "The Book is Very good. Turning Point for life"

            };

            db.Reviews.Add(review1);
            db.SaveChanges();

        }
    }
}
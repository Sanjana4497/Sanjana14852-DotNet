﻿select * from Book
select * from Publisher
select * from Review
select * from Member
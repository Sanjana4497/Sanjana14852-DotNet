﻿select * from Book
select * from Review
select * from Publisher
select * from Member
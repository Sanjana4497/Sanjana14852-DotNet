﻿Select * from Images
Select * from Product
Select * from Category

update Images 
set ImageUrl = NULL where ImageId = 1
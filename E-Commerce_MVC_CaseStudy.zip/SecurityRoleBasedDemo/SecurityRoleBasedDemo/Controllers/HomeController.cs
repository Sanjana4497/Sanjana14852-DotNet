﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SecurityRoleBasedDemo.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace SecurityRoleBasedDemo.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly UserManager<MyIdentityUser> userManager;
        public HomeController(ILogger<HomeController> logger, UserManager<MyIdentityUser> _userManager)
        {
            _logger = logger;
            userManager = _userManager;
        }

        public IActionResult Default()
        {
            return View();
        }

        //It will Redirect Normal User to the Index Page
        [Authorize]
        public IActionResult Index()
        {
            MyIdentityUser user = userManager.GetUserAsync(HttpContext.User).Result;

            ViewBag.Message = $"Welcome {user.FullName}!";

            if (userManager.IsInRoleAsync(user, "NormalUser").Result)
            {
                ViewBag.RoleMessage = "You are a Normal User.";
            }
            return View();
        }

        //This view is Accessible only to Admin
        [Authorize(Roles ="admin")]

        public IActionResult OnlyAdminAccess()
        {
            ViewBag.role = "Admin";
            MyIdentityUser user = userManager.GetUserAsync(HttpContext.User).Result;
            ViewBag.Message = $"Welcome {user.FullName}!";
            return View();
        }

        //This view is only available for Normal User
        [Authorize(Roles ="NormalUser")]
        public IActionResult OnlyNormalUser()
        {
            ViewBag.role = "NormalUser";
            MyIdentityUser user = userManager.GetUserAsync(HttpContext.User).Result;
            ViewBag.Message = $"Welcome {user.FullName}!";
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

﻿using System;

namespace NUnitLib
{
    public class Calculator
    {
        public int Addition(int first, int second)
        {
            return first + second;
        }

        public int Subtraction(int first, int second)
        {
            if( first < second)
            {
                throw new ArgumentException($"First number {first} is less than the second number {second}");
            }
            return first - second;
        }
        //method division
        //take 2 integer parameters
        //return int

        //if second number is 0 throw DivideByZeroException
        //if any number is negative throw ArgumentException


        //-------------------inTest class
        //write 3 Test method
        //1  check return value
        //2 check for DivideByZeroException
        //3 check for ArgumentException

        //public int Division(int first, int second)
        //{
        //    if ( second = 0 )
        //    {
        //        throw new DivideByZeroException($"First number {first} is less than the second number {second}");
        //    }
        //    return first - second;
        //}

        public int Division(int first, int second)
        {
            if (second == 0)
            {
                throw new DivideByZeroException($"Second number{second} is zero");
            }
            else if (first < 0 || second < 0)
            {
                throw new ArgumentException($"First number{first} or second number{second} is negative");
            }
            return first / second;
        }


    }
}

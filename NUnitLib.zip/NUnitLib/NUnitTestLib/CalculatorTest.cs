﻿using System;
using NUnit.Framework;
using NUnitLib;


namespace NUnitTestLib
{
    public class CalculatorTest
    {
        Calculator calculator;

        //run one time only to initialize before executing any test method
        [OneTimeSetUp]
        public void Init()
        {
           // calculator = new Calculator();
        }


        //run at the end after completing all test method
        [OneTimeTearDown]
        public void Cleanup()
        {
           // calculator = null;
        }

        //setup method will run before every test
        [SetUp]
        public void Setup()
        {
            calculator = new Calculator();
        }


        [TearDown]
        //teardown method will run after completing every test method
        public void TearDown()
        {
           calculator = null;
        }


        [Test]
        //public void Test_Addition_With_Valid_Integers()
        //{
        //   // Calculator calculator = new Calculator();
        //    int result = calculator.Addition(5, 3);

        //    //Assert.AreEqual(expected, actual)
        //    Assert.AreEqual(8, result);
        //}

       // [Test]
        //public void Test_Addition_With_Valid_Negative_Integers()
        //{
        //   // Calculator calculator = new Calculator();
        //    int result = calculator.Addition(-5, -3);

        //    //Assert.AreEqual(expected, actual)
        //    Assert.AreEqual(-8, result);
        //}
       // [Test]
        //[Ignore("ignore")]
        //public void Test_Subtraction_Argument_Exception()
        //{
        //   // Calculator calculator = new Calculator();
        //    Assert.Catch<ArgumentException>(() => calculator.Subtraction(3, 5));
        //   // Assert.Throws<ArgumentException>(() => calculator.Subtraction(3, 5));
        //}

        //multiple case arguments
        //[TestCase(1,2,3)]
        //[TestCase(-1, -2, -3)]
        //[TestCase(3, -5, -2)]
        //[TestCase(-5, 3, -2)]
        //[TestCase(0, 0, 0)]
        //public void Test_Addition_Multiple(int first, int second, int expectedresult)
        //{
        //   // Calculator calculator = new Calculator();
        //    int result = calculator.Addition(first, second);
        //    Assert.AreEqual(expectedresult, result);
        //}

       // [Test]
        public void Test_Division_With_Valid_Integers()
        {
            int result = calculator.Division(10, 5);
            Assert.AreEqual(2, result);
        }



        [Test]
        public void Test_Division_With_Second_Number_Zero()
        {
            Assert.Catch<DivideByZeroException>(() => calculator.Division(15, 0));
        }



        [Test]
        public void Test_Division_With_Any_Negative_Integer()
        {
            Assert.Catch<ArgumentException>(() => calculator.Division(10, -5));
        }
    }

    //[Ignore("Ignore test")]
    //    public void Test_To_Ignore()
    //    {

    //    }
    }




﻿using System;

namespace GuidAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Guid guid = Guid.NewGuid();
            Console.WriteLine("The newly created Guid is: " + guid.ToString());
            Console.ReadKey();
            Guid id = new Guid();
            if (id == Guid.Empty)
                Console.WriteLine("The Guid is empty");
            if (guid != Guid.Empty)
            {
                //The GUID object contains non-zero values
            }
            else
            {
                //The GUID object is empty
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Models
{
    public class Attendies
    {
        [Required(ErrorMessage = "Please enter your name")]
       // [RegularExpression(@"[0-9]{4}", ErrorMessage = "Enter four digit EmpId")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter your email id")]
       // [StringLength(10, ErrorMessage = "Maximum EmpName length is 10 characters")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your phone number")]
        public int? Phone { get; set; }

        [Required(ErrorMessage = "Please specify whether you'll attend")]
        public bool? WillAttend { get; set; }
    }
}

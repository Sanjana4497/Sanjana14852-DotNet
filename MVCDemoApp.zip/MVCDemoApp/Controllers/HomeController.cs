﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MVCDemoApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MVCDemoApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        //run the code
        //pass the value for parameter "name" using route parameter and not query string
        //display in browser

        [Route("Home/Greet/{name?}")]
        public IActionResult Greet(string name)
        {
            //return Content("Welcome to mvc");
            // return View("Greet1"); //when we change the view's name
            ViewBag.wish = "Hello " + name;
            return View();
        }

        public IActionResult GetData(int id)
        {
            ViewBag.message = "Id = " + id;
            return View();
        }

        //create an action - AddNumbers
        // which takes 2 integer parameters
        //display addition of 2 numbers in browsers



        [Route("home/sum/{num1:int:range(1,25)}/{num2:int:range(1,5)}")]
        public IActionResult AddNumbers(int num1=0, int num2=0)
        {
            int result = num1 + num2;
            ViewBag.result = $" {num1} + {num2} = {result} ";
            return View();
        }

        public IActionResult ModelDemo()
        {
            Employee employee = new Employee { EmpId = 1, EmpName = "sanjana", Salary = 10000 };
            //ViewBag.emp = employee;
            ViewData["emp"] = employee;
            return View();
        }

       public IActionResult EmployeeForm()
        {
            return View(new Employee());
        }

        public IActionResult DisplayEmployeeData(Employee employee)
        {
            if (ModelState.IsValid)
            {
                return View(employee);
            }
            return View("EmployeeForm", employee);
        }

        public IActionResult HTMLHelperDemo()
        {
            return View(new Employee { EmpId = 501, EmpName = "sanjana", Salary = 1000 });
        }

    }
}

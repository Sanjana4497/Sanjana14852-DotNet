﻿using System;

namespace DataAccessLayerLib
{
    public class Emp
    {
        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public DateTime? HireDate { get; set; }
        public decimal? Salary { get; set; }

        public override string ToString()
        {
            return string.Format($"Empno = {EmpNo} EmpName = {EmpName} Hiredate = (HireDate) Salary = {Salary}");
        }

    }
}

﻿


//        //GetAllEmps - return all emps data from table



//        public List<Emp> GetAllEmps()
//        {
//            try
//            {
//                string sql = "select * from EMP";
//                command = new SqlCommand(sql, connection);
//                if (connection.State == ConnectionState.Closed)
//                {
//                    connection.Open();
//                }
//                reader = command.ExecuteReader();
//                List<Emp> empList = new List<Emp>();

//                while (reader.Read())
//                {
//                    Emp emp = new Emp();
//                    emp.EmpNo = (int)reader["EmpNo"];
//                    emp.EmpName = reader["Ename"].ToString();
//                    emp.HireDate = (DateTime)reader["HireDate"];
//                    emp.Salary = (decimal)reader["Sal"];
//                    empList.Add(emp);

//                }
//                return empList;
//            }
//            catch (SqlException)
//            {
//                throw;
//            }
//            finally
//            {
//                connection.Close();
//            }
//        }

//        public Emp GetEmpbyNo(int empno)
//        {

//            try
//            {
//                string sql = "select * from emp where empno = @empno";
//                command = new SqlCommand(sql, connection);
//                command.Parameters.AddWithValue("empno", empno);
//                if (connection.State == ConnectionState.Closed)
//                {
//                    connection.Open();
//                }
//                reader = command.ExecuteReader();

//                Emp emp = null;
//                while (reader.Read())
//                {
//                    emp = new Emp();
//                    emp.EmpNo = (int)reader["EmpNo"];
//                    emp.EmpName = reader["Ename"].ToString();
//                    emp.HireDate = reader["HireDate"] as DateTime?;
//                    emp.Salary = reader["Sal"] as decimal?;


//                }
//                return emp;
//            }
//            catch (SqlException)
//            {
//                throw;
//            }
//            finally
//            {
//                connection.Close();
//            }
//        }

//        //Addemp
//        //write a method which takes information and add emp to db table

//        public int AddEmp(Emp emp)
//        {
//            try
//            {
//                string sql = "insert into Emp(Empno,Ename,hiredate,sal) values(@empno,@empname,@hiredate,@salary)";
//                command = new SqlCommand(sql, connection);
//                command.Parameters.AddWithValue("empno", emp.EmpNo);
//                command.Parameters.AddWithValue("empname", emp.EmpName);
//                command.Parameters.AddWithValue("hiredate", emp.HireDate);
//                command.Parameters.AddWithValue("salary", emp.Salary);

//                if (connection.State == ConnectionState.Closed)
//                {
//                    connection.Open();
//                }
//                int count = command.ExecuteNonQuery();

//                return count;
//            }
//            catch (SqlException)
//            {
//                throw;
//            }
//            finally
//            {
//                connection.Close();
//            }
//        }

//        public int RemoveEmp(int empno)
//        {
//            try
//            {
//                string sql = "delete from emp where empno=@empno";
//                command = new SqlCommand(sql, connection);
//                command.Parameters.AddWithValue("empno", empno);

//                if (connection.State == ConnectionState.Closed)
//                {
//                    connection.Open();
//                }
//                int count = command.ExecuteNonQuery();

//                return count;
//            }
//            catch (SqlException)
//            {
//                throw;
//            }
//            finally
//            {
//                connection.Close();
//            }
//        }

//        public int ModifyEmp(Emp empobj)
//     


using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;



namespace DataAccessLayerLib
{
    public class EmpDataStore
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;

       // public SqlConnection Connection { get; set; }
        public EmpDataStore() { }


        public EmpDataStore(string connectionString)
        {
            connection = new SqlConnection(connectionString);
        }

        public void SetConnection(string connectionstring)
        {
            connection = new SqlConnection(connectionstring);
        }




        //GetAllEmps - return all emps data from table



        public List<Emp> GetAllEmps()
        {
            try
            {
                string sql = "select * from EMP";
                command = new SqlCommand(sql, connection);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                reader = command.ExecuteReader();
                List<Emp> empList = new List<Emp>();

                while (reader.Read())
                {
                    Emp emp = new Emp();
                    emp.EmpNo = (int)reader["EmpNo"];
                    emp.EmpName = reader["Ename"].ToString();
                    emp.HireDate = reader["HireDate"] as DateTime?;
                    emp.Salary = reader["Sal"] as decimal?
                        ;
                    empList.Add(emp);

                }
                return empList;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public Emp GetEmpbyNo(int empno)
        {

            try
            {
                string sql = "select * from emp where empno = @empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empno);
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                reader = command.ExecuteReader();

                Emp emp = null;
                while (reader.Read())
                {
                    emp = new Emp();
                    emp.EmpNo = (int)reader["EmpNo"];
                    emp.EmpName = reader["Ename"].ToString();
                    emp.HireDate = reader["HireDate"] as DateTime?;
                    emp.Salary = reader["Sal"] as decimal?;


                }
                return emp;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //Addemp
        //write a method which takes information and add emp to db table

        public int AddEmp(Emp emp)
        {
            try
            {
                string sql = "insert into Emp(Empno,Ename,hiredate,sal) values(@empno,@empname,@hiredate,@salary)";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", emp.EmpNo);
                command.Parameters.AddWithValue("empname", emp.EmpName);
                command.Parameters.AddWithValue("hiredate", emp.HireDate);
                command.Parameters.AddWithValue("salary", emp.Salary);

                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                int count = command.ExecuteNonQuery();

                return count;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public int RemoveEmp(int empno)
        {
            try
            {
                string sql = "delete from emp where empno=@empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empno);

                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                int count = command.ExecuteNonQuery();

                return count;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        public int ModifyEmp(Emp empobj)
        {
            try
            {
                string sql = "update emp set ename=@empname, hiredate=@hiredate, sal=@salary where Empno=@empno";
                command = new SqlCommand(sql, connection);
                command.Parameters.AddWithValue("empno", empobj.EmpNo);
                command.Parameters.AddWithValue("empname", empobj.EmpName);
                command.Parameters.AddWithValue("hiredate", empobj.HireDate);
                command.Parameters.AddWithValue("salary", empobj.Salary);

                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                int count = command.ExecuteNonQuery();

                return count;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}















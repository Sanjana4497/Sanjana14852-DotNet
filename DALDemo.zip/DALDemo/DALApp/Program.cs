﻿using System;
using System.Collections.Generic;
using DataAccessLayerLib;


namespace DALApp
{
    class Program
        {
            static void Main(string[] args)
            {
                Program program = new Program();
                program.DisplayAllEmp();

                Console.WriteLine("--------------------------------------------------------------");
                //Console.WriteLine("Enter Emp no: ");
                //int eno = Convert.ToInt32(Console.ReadLine());
                //program.DisplayEmpbyNo(eno);
                //program.InsertEmployee();

                //Console.WriteLine("Enter emp no: ");
                //int empno = Convert.ToInt32(Console.ReadLine());
                //program.DeleteRecord(empno);
                //program.DisplayAllEmp();

                program.UpdateEmpDetails();
                program.DisplayAllEmp();

            }

            EmpDataStore empDataStore;

            public Program()
            {
                empDataStore = new EmpDataStore(@"server=(localdb)\MSSQLLocalDB;database=Training; Integrated Security=True;");

            }

            void DisplayAllEmp()
            {
                List<Emp> empList = empDataStore.GetAllEmps();
                foreach (Emp item in empList)
                {
                    Console.WriteLine(item);
                }
            }

            void DisplayEmpbyNo(int empno)
            {
                Emp emp = empDataStore.GetEmpbyNo(empno);
                if (emp != null)
                {
                    Console.WriteLine(emp);
                }
                else
                {
                    Console.WriteLine($"Emp with empno {empno} not found");
                }
            }

            void InsertEmployee()
            {
                Console.WriteLine("Enter emp no: ");
                int empno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Employee name: ");
                string empname = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Hiredate: ");
                DateTime doh = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Salary: ");
                decimal salary = Convert.ToDecimal(Console.ReadLine());

                Emp newEmp = new Emp()
                {
                    EmpNo = empno,
                    EmpName = empname,
                    HireDate = doh,
                    Salary = salary

                };
                int result = empDataStore.AddEmp(newEmp);
                if (result == 1)
                {
                    Console.WriteLine("Record inserted successully");
                }
                else
                {
                    Console.WriteLine("Failed to insert");
                }

            }

            void DeleteRecord(int empno)
            {

                int result = empDataStore.RemoveEmp(empno);
                if (result == 1)
                {
                    Console.WriteLine("Record deleted successully");
                }
                else
                {
                    Console.WriteLine("Failed to delete");
                }

            }

            void UpdateEmpDetails()
            {
                Console.WriteLine("Enter emp no: ");
                int empno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Employee name: ");
                string empname = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Hiredate: ");
                DateTime hiredate = Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Salary: ");
                decimal salary = Convert.ToDecimal(Console.ReadLine());

                Emp newEmp = new Emp()
                {
                    EmpNo = empno,
                    EmpName = empname,
                    HireDate = hiredate,
                    Salary = salary

                };
                int result = empDataStore.ModifyEmp(newEmp);
                if (result == 1)
                {
                    Console.WriteLine("Record Updated successully");
                }
                else
                {
                    Console.WriteLine("Failed to update");
                }

            }
        }
    }









